// fantasia, aventura, drama

// a viagem de chihiro, LIVRE, fantasia, aventura
// guardioes da galaxia, 12, fantasia, aventura
// as aventuras de pi 10, drama, fantasia, aventura
// paddington, LIVRE, fantasia, aventura
// ladroes de bicicleta, 12, drama
// o menino que descobriu o vento, 14, drama



let campoIdade;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("gosta de fantasia?")
}

function draw() {
  background(220);
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia);
  textAlign(CENTER,CENTER);
  textSize(35);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia){
  if(idade >=10){
  if(idade >= 14){
    return "O Menino que Descobriu o Vento";
  } else {
    if(idade >= 12){}
      if (gostaDeFantasia){
    return "As Aventuras de Pi"
    } else  {
    return "Depois da Chuva";
  }
 } 
} else {
  if(gostaDeFantasia){
    return "A Viagem de Chihiro";
  } else {
    return "O Feitico do Tempo"
  }
 }
}